param ( 
    [Parameter(Mandatory = $false)][string]$installNodePrerequisites = "false" 
) 

. .\generic_functions.ps1

Write-host Installing prerequisites, please wait...

InstallScoopIfNeeded

CheckAndInstallWithScoop "git"
CheckAndInstallWithScoop "winget"
CheckAndInstallWithScoop "nvm"

if ($installNodePrerequisites -eq "true")
{
	CheckNodePrerequisites 
}

$existBucket = ExistBucket "extras" 
if ($existBucket -eq $false)
{
	scoop bucket add extras
}

Write-host "installing Microsoft.DotNet.HostingBundle"
winget install --id $netHostBundleId -e -h --accept-source-agreements --accept-package-agreements >$null

Write-host "installing Microsoft.VCRedist..."
winget install --id=$vcRedistId -e -h --accept-source-agreements --accept-package-agreements >$null

Write-Host prerequisites successfully installed
