. .\generic_functions.ps1

$isScoopInstalled = IsScoopInstalled
$isGitInstalled = CheckIfAppExistInScoop "git"
$isWingetInstalled = CheckIfAppExistInScoop "winget"
$isNvmInstalled = CheckIfAppExistInScoop "nvm"
$isNetHostBundleInstalled = CheckWingetPackageExistance $netHostBundleId
$isVcRedistInstalled = CheckWingetPackageExistance $vcRedistId
$isBucketExtraInstalled = ExistBucket "extras" 

if (
    $isScoopInstalled -eq $true -and
    $isGitInstalled -eq $true -and
    $isWingetInstalled -eq $true -and
    $isNvmInstalled -eq $true -and
    $isNetHostBundleInstalled -eq $true -and
    $isVcRedistInstalled -eq $true -and
    $isBucketExtraInstalled -eq $true
)
{
    exit 0
}

exit 1


